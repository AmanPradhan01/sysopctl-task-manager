#!/bin/bash

# sysopctl - System Operations Command Line Tool v0.1.0

VERSION="0.1.0"

# Display the help menu
display_help() {
    echo "Usage: sysopctl [COMMAND] [OPTIONS]"
    echo ""
    echo "Commands:"
    echo "  service list               List running services"
    echo "  service start <service>    Start a service"
    echo "  service stop <service>     Stop a service"
    echo "  system load                View system load averages"
    echo "  disk usage                 Show disk usage statistics"
    echo "  process monitor            Monitor system processes"
    echo "  logs analyze               Analyze system logs"
    echo "  backup <path>              Backup system files"
    echo ""
    echo "Options:"
    echo "  --help                     Show help documentation"
    echo "  --version                  Show the version of sysopctl"
    exit 0
}

# Display version information
display_version() {
    echo "sysopctl version $VERSION"
    exit 0
}

# List running services
list_services() {
    echo "Listing all running services..."
    systemctl list-units --type=service
    exit 0
}

# Start a service
start_service() {
    local service_name=$1
    if [[ -n "$service_name" ]]; then
        echo "Starting service: $service_name"
        systemctl start "$service_name"
        echo "Service $service_name started."
    else
        echo "Please specify a service to start."
    fi
    exit 0
}

# Stop a service
stop_service() {
    local service_name=$1
    if [[ -n "$service_name" ]]; then
        echo "Stopping service: $service_name"
        systemctl stop "$service_name"
        echo "Service $service_name stopped."
    else
        echo "Please specify a service to stop."
    fi
    exit 0
}

# View system load averages
view_system_load() {
    echo "Current system load averages:"
    uptime
    exit 0
}

# Show disk usage statistics
check_disk_usage() {
    echo "Disk usage statistics by partition:"
    df -h
    exit 0
}

# Monitor system processes in real-time
monitor_processes() {
    echo "Monitoring system processes..."
    top
    exit 0
}

# Analyze recent critical system logs
analyze_logs() {
    echo "Analyzing recent critical logs..."
    journalctl -p 3 -xb
    exit 0
}

# Backup system files
backup_files() {
    local path_to_backup=$1
    local backup_dir="/path/to/backup/directory"

    if [[ -n "$path_to_backup" ]]; then
        echo "Backing up files from $path_to_backup..."
        rsync -av "$path_to_backup" "$backup_dir"
        echo "Backup completed for $path_to_backup to $backup_dir."
    else
        echo "Please specify the path to backup."
    fi
    exit 0
}

# Parse command-line arguments
if [[ "$1" == "--help" ]]; then
    display_help
elif [[ "$1" == "--version" ]]; then
    display_version
elif [[ "$1" == "service" && "$2" == "list" ]]; then
    list_services
elif [[ "$1" == "service" && "$2" == "start" && -n "$3" ]]; then
    start_service "$3"
elif [[ "$1" == "service" && "$2" == "stop" && -n "$3" ]]; then
    stop_service "$3"
elif [[ "$1" == "system" && "$2" == "load" ]]; then
    view_system_load
elif [[ "$1" == "disk" && "$2" == "usage" ]]; then
    check_disk_usage
elif [[ "$1" == "process" && "$2" == "monitor" ]]; then
    monitor_processes
elif [[ "$1" == "logs" && "$2" == "analyze" ]]; then
    analyze_logs
elif [[ "$1" == "backup" && -n "$2" ]]; then
    backup_files "$2"
else
    echo "Unknown command. Use --help for usage information."
    exit 1
fi
